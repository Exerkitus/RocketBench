# RocketBench

(https://guides.github.com/features/mastering-markdown/)

This is a little project to develop a toolbox for designing liquid-fuelled rocket engines.